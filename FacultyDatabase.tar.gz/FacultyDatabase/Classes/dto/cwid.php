<?php
class cwid extends Thread{
	
}

?>